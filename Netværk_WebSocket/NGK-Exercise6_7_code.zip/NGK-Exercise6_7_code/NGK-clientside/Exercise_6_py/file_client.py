#!/usr/bin/python3

import sys
from socket import socket, AF_INET, SOCK_STREAM
from lib import Lib
import os.path
import datetime

PORT = 9000
serverName = "10.0.0.1"
BUFSIZE = 1000


def main(argv):
    # TO DO Your Code
    clientSocket = socket(AF_INET, SOCK_STREAM)
    print("The client is connecting...")
    clientSocket.connect((serverName, PORT))
    print("Client connected")

    messageToServer = input("Input filepath:") #Get filepath as input

    receiveFile(messageToServer, clientSocket)


def receiveFile(fileName, conn):
    # TO DO Your Code
    # https://stackoverflow.com/questions/51512621/python-3-sending-files-through-socket-client-server-program
    # https://www.youtube.com/watch?v=Kg-sxVmCt5Q
    conn.send(fileName.encode())#'utf-8'

    file = open('my_image.jpeg', "wb") #open new image file with -write options
    image_chunk = conn.recv(BUFSIZE)  #recieve first 1000 bytes
    n = 1 #counter for status print
    while image_chunk:
        file.write(image_chunk) #Write 1000 bytes to new image
        print (f'Recieved {n}. chunk')# Print status
        image_chunk = conn.recv(BUFSIZE) # Recieve next 1000 bytes
        n = n +1 #Increment counter
        
    file.close()
    conn.close()


if __name__ == "__main__":
    main(sys.argv[1:])
