#!/usr/bin/python3

import sys
from socket import socket, AF_INET, SOCK_STREAM, SOCK_DGRAM
from lib import Lib
import os.path
import datetime

PORT = 9000


def main(argv):
    
    serverName = "10.0.0.1"

    print ("Client is starting...")
    clientSocket = socket(AF_INET, SOCK_DGRAM)
    
    x = 0
    while x < 1:
        messagetoserver = input('Input command: ')
        
        if messagetoserver == 'u':
            x = x +1
        elif messagetoserver == 'U':
            x = x +1
        elif messagetoserver == 'l':
                x = x +1
        elif messagetoserver == 'L':
                x = x +1
        else:
            print ("No valid input")

    clientSocket.sendto(messagetoserver.encode(), (serverName, PORT))
    receiveInfo(clientSocket)
    clientSocket.close()

def receiveInfo(clientSocket):
    file = open('data.txt',"wb")
    chunk = clientSocket.recvfrom(2048)
    messagefromchunk = chunk[0]
    print(messagefromchunk)
    file.close()



if __name__ == "__main__":
    main(sys.argv[1:])
