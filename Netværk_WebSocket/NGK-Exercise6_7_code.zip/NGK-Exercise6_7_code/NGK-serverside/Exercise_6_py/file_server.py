#!/usr/bin/python3

import sys
import os
from socket import socket, AF_INET, SOCK_STREAM
from lib import Lib


HOST = ""
PORT = 9000
BUFSIZE = 1000


def main(argv):
    
    # Create TCP welcoming socket
    serverSocket = socket(AF_INET, SOCK_STREAM)
    serverSocket.bind((HOST, PORT))
    serverSocket.listen(1)  # Server begins listening for incoming TCP requests

    while 1:
        print("The server is ready to accept file request")
        connectionSocket, addr = serverSocket.accept()
        print("Socket accept", addr)
        # https://stackoverflow.com/questions/51512621/python-3-sending-files-through-socket-client-server-program
        
        data = connectionSocket.recv(BUFSIZE).decode('utf-8') #File request

        print(data)
        sendFile(data, os.path.getsize(data), connectionSocket)

        connectionSocket.close()


def sendFile(fileName,  fileSize,  conn):
    # TO DO Your Code

    myfile = open(fileName, "rb")
    print (fileSize, "bytes")
    # https://thepythonguru.com/python-how-to-read-and-write-files/
    # https://www.youtube.com/watch?v=Kg-sxVmCt5Q
    chunk = myfile.read(BUFSIZE) #Read 1000bytes
    n = 1 #counter for print status
    while chunk:
        conn.send(chunk) # Send 1000 bytes
        chunk = myfile.read(BUFSIZE) # Read next
        print (f'Send {n}. chunk') #Print status
        n = n + 1 # Increment counter

    myfile.close()
    conn.close()

if __name__ == "__main__":
    main(sys.argv[1:])
