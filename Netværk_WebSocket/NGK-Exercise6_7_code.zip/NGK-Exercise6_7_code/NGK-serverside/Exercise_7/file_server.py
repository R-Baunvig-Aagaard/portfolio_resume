#!/usr/bin/python3

import sys
import os
from socket import socket, AF_INET, SOCK_STREAM, SOCK_DGRAM
from lib import Lib


HOST = ""
PORT = 9000

def main(argv):
    
    # Create UDP welcoming socket
    UDPServerSocket = socket(AF_INET, SOCK_DGRAM) #Datagram socket
    UDPServerSocket.bind((HOST,PORT))   #Bind adress and IP

    print ("Server is running")
    
    while 1:
        bytesAdressPair = UDPServerSocket.recvfrom(2048)
        message = bytesAdressPair[0]        #Extract message from UDP packet
        clientAdress = bytesAdressPair[1]   #Extract client adress from UDP packet
        print ("Message received from client", clientAdress, ":", message.decode('utf-8') )

        message = message.decode('utf-8').upper()
        print( message)

        answerRequest(UDPServerSocket,message, clientAdress)



    
def answerRequest(UDPServerSocket,request, clientAdress):
        
        if request == 'U':
                print( "Uptime was requested")
                myfile = open("/proc/uptime", "r")
                chunk = myfile.read(2048)
                print(chunk)

                UDPServerSocket.sendto(chunk.encode(), clientAdress)
                myfile.close()

        if request == 'L':
                print("Loadavg was requested")
                myfile = open("/proc/loadavg", "r")
                chunk = myfile.read(2048)
                print(chunk)

                UDPServerSocket.sendto(chunk.encode(), clientAdress)
                myfile.close()
        

if __name__ == "__main__":
    main(sys.argv[1:])
